from param_checker import param_check
import json
import openai
from openai import OpenAI
import traceback
import os
from gpt_rewriter import article_generator
from dotenv import load_dotenv, find_dotenv


_ = load_dotenv(find_dotenv())
client = OpenAI()
client.api_key = os.getenv("OPENAI_API_KEY")


def lambda_handler(event_jsonified, context):
    outputs = {}
    event = event_jsonified['body']
    event = json.loads(event, strict = False)
    
    try:
        
        request_fields = event.keys()
        
        if 'toolType' not in request_fields:
            outputs['error'] = 'Required field, toolType, is missing. Please check your input.'
                
            return {
            'statusCode': 400,
            'headers': {
                        'Access-Control-Allow-Headers': '*',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': '*'
                    },
            'body': json.dumps(outputs)
            }
        
        toolTypes = {
        "article_generator": ["post_ids", "posts"]
        }
            
        tooltype = event['toolType']
        if tooltype not in toolTypes.keys():
            outputs['error'] = f'No such tool exists {tooltype}'            
            return {
                'statusCode': 404,
                'headers': {
                            'Access-Control-Allow-Headers': '*',
                            'Access-Control-Allow-Origin': '*',
                            'Access-Control-Allow-Methods': '*'
                        },
                'body': json.dumps(outputs)
            }         
        else:
            status = param_check(params_provided=request_fields, params_required=toolTypes.get(tooltype))
            if isinstance(status, dict):
                return status
        
        if tooltype == 'article_generator':
            post_ids = event['post_ids']
            posts = event["posts"]
            out = article_generator(post_ids, posts)

        if isinstance(out, dict):
            if 'statusCode' in out.keys():
                return out
            if 'articles' in out.keys() and 'focus_keywords' in out.keys():
                outputs['articles'] = out['articles']
                outputs['focus_keywords'] = out['focus_keywords']
                return {
                    'statusCode': 200,
                    'headers': {
                        'Access-Control-Allow-Headers': '*',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': '*'
                    },
                    'body': json.dumps(outputs)
        } 
                                
    except TypeError as e:
        outputs['error'] = str(e)
                
        return {
            'statusCode': 400,
            'headers': {
                        'Access-Control-Allow-Headers': '*',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': '*'
                    },
            'body': json.dumps(outputs)
        }
    
    except Exception as e:
        outputs['error'] = str(traceback.format_exc())
                
        return {
            'statusCode': 500,
            'headers': {
                        'Access-Control-Allow-Headers': '*',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': '*'
                    },
            'body': json.dumps(outputs)
        }
