import json


def param_check(params_provided: list, params_required: list)-> bool or list:
    """
    Check weather provided params are correct or not.

    Parameters
    ----------
    list
        
    list
        
    Returns
    -------
    bool or list

    """
    
    err = []
    params_required.insert(0, 'toolType')
    for provided in params_provided:
        if provided not in params_required:
            err += [
                f"Invalid parameter: '{provided}'"
            ]
    for req in params_required:
        if req not in params_provided:
            err += [
                f"Parameter missing: '{req}'"
            ]
    if len(err):
        err.append(f'Note: parameters are case sensitive.')

        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': '*'
            },
            'body': json.dumps(
                {
                    "error": err,
                    "Required Parameters": params_required
                }
            )
        }
    return True
    